<?php

namespace App\Models\Admin;

use App\Models\Category;
use Illuminate\Database\Eloquent\Model;

class CompanyCategory extends Model
{
    protected $table = 'sisterconcern_category';
    protected $fillable = [
        'sisterconcern_id',
        'category_id'
    ];

    public function category()
    {
        return $this->hasMany(Category::class, 'id', 'category_id');
    }
}
