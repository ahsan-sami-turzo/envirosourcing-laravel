<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class WhyChoose extends Model
{
    protected $guarded;
}
